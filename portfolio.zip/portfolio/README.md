# Hafiza Saifa Shahid — Live GitHub Portfolio

A static portfolio that fetches, analyzes, and renders your GitHub profile and
repositories at page-load time. There is no build step and no backend — the
site is `index.html` + `css/style.css` + four small `js/` files, and every
piece of content comes from `https://api.github.com/users/wwwsaifashahid-a11y`
in the visitor's own browser.

## How it works

```
GitHub API  →  js/github-api.js       (fetch + in-memory cache)
            →  js/github-analyzer.js  (turn raw repo data into project content)
            →  js/portfolio-renderer.js (render into the DOM)
```

- **js/config.js** — the only hardcoded identity value is your GitHub
  username. Change it here and nothing else needs to be touched.
- **js/github-api.js** — talks to the GitHub REST API (profile, repos,
  languages, topics, README, root file listing) and caches each response in
  memory for 30 minutes so a single page view doesn't hammer the API.
- **js/github-analyzer.js** — turns a raw repo into portfolio content:
  title-cases the repo name, detects technologies from language/topics/
  description/README text, pulls Problem/Solution sections out of the
  README when present, decides whether a repo is a real project, a
  practice/learning repo, or the portfolio's own source (matched by name
  containing "portfolio"), and scores projects for the Featured ranking.
  This logic is generic — it runs the same way on a repo you push tomorrow
  as it does on the five you have today.
- **js/portfolio-renderer.js** — the only file that touches the DOM. Renders
  the hero, About paragraph, Featured/All Projects, Skills, GitHub Activity,
  Contact section, project-detail modal, and wires the CV button, contact
  form, and modal interactions.

## Updating your portfolio

Push a new public repository (or update an existing one's README/
description/topics) and refresh the page. Nothing in this codebase needs
to change.

## Publishing it

The simplest option is GitHub Pages:

1. Push this folder's contents to a repo (e.g. rename/reuse `My-Portfolio`).
2. In that repo's **Settings → Pages**, set the source to the branch/root
   you pushed to.
3. Your site will be live at `https://wwwsaifashahid-a11y.github.io/<repo>/`.

Any static host works too (Netlify, Vercel, Cloudflare Pages) — just deploy
the folder as-is.

## Things worth knowing

- **Unauthenticated GitHub API rate limit is 60 requests/hour per visitor
  IP.** For 5 repos this site makes roughly 1 (profile) + 1 (repo list) +
  4 calls per repo ≈ 22 requests — comfortably under the limit for a normal
  visitor. If a visitor's IP happens to be near the limit already (shared
  office/school networks, some VPNs), the page shows a plain-language error
  instead of breaking, and works again once the limit resets.
- **CV button** only appears if a file named like `cv.pdf`, `resume.pdf`,
  etc. is found in a repo's root — otherwise it stays hidden rather than
  linking to nothing.
- **Contact email** only appears if it's public on your GitHub profile
  (Settings → Public profile → Public email). If it's private, the contact
  form tells visitors to use the GitHub link instead of silently failing.
- **Social preview tags** (Open Graph/Twitter meta) are set once, statically,
  from your account's known focus — they can't be populated live by
  JavaScript because social crawlers don't execute it. Update the `<meta>`
  values in `index.html` directly if your headline focus changes.
- I could not verify this against the *live* GitHub API from this session —
  the sandbox's shared IP had already hit GitHub's 60-req/hour unauthenticated
  limit. I validated the full fetch → analyze → render → modal pipeline
  instead by simulating the page with mocked API responses shaped like your
  five real repositories (including the README-driven Problem/Solution/
  Workflow extraction for the ticket-assistant project) — it ran end-to-end
  with no errors. Open `index.html` in a browser to see it run against your
  real, live data.
