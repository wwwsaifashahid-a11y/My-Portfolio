/**
 * config.js
 * The ONLY place a human identity is hardcoded: the GitHub username.
 * Everything else in this site is derived from what the GitHub API returns
 * for this account. Change GITHUB_USERNAME and refresh — nothing else
 * needs to be touched.
 */
window.PORTFOLIO_CONFIG = {
  GITHUB_USERNAME: "wwwsaifashahid-a11y",
  // How long fetched GitHub data stays cached in memory (per page load)
  // before a fresh call is made (ms). Keeps the site fast and avoids
  // hammering GitHub's unauthenticated rate limit (60 requests/hour/IP).
  CACHE_TTL_MS: 1000 * 60 * 30, // 30 minutes
  // Repos whose name matches this pattern are treated as "this site's own
  // source" rather than a primary project — used for design reference only.
  SELF_REPO_PATTERN: /portfolio/i,
};
