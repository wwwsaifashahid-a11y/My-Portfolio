/**
 * js/github-analyzer.js
 * Turns raw GitHub API data into portfolio-shaped content.
 * Every rule here is generic (name patterns, keyword evidence, file
 * presence) — nothing is keyed to a specific repo name, so a brand new
 * repository is analyzed the same way as an existing one.
 */
(function () {
  // Keyword → { label, category } lookup used to detect technologies from
  // repo language, description, topics and README text. Matching is
  // case-insensitive and word-boundary aware.
  const TECH_DICTIONARY = [
    { re: /\bpython\b/i, label: "Python", category: "Programming" },
    { re: /\bjavascript\b|\bjs\b/i, label: "JavaScript", category: "Programming" },
    { re: /\btypescript\b/i, label: "TypeScript", category: "Programming" },
    { re: /\bhtml5?\b/i, label: "HTML5", category: "Web Development" },
    { re: /\bcss3?\b/i, label: "CSS3", category: "Web Development" },
    { re: /\bdjango\b/i, label: "Django", category: "Web Development" },
    { re: /\bflask\b/i, label: "Flask", category: "Web Development" },
    { re: /\breact\b/i, label: "React", category: "Web Development" },
    { re: /\bnode(\.js)?\b/i, label: "Node.js", category: "Web Development" },
    { re: /\bbootstrap\b/i, label: "Bootstrap", category: "Web Development" },
    { re: /\baos\b|animate on scroll/i, label: "AOS Animations", category: "Web Development" },
    { re: /\bsqlite3?\b/i, label: "SQLite", category: "Databases" },
    { re: /\bmysql\b/i, label: "MySQL", category: "Databases" },
    { re: /\bpostgres(ql)?\b/i, label: "PostgreSQL", category: "Databases" },
    { re: /\bmongodb\b/i, label: "MongoDB", category: "Databases" },
    { re: /\bn8n\b/i, label: "n8n", category: "AI & Automation" },
    { re: /\bmake\.com\b|\bintegromat\b/i, label: "Make.com", category: "AI & Automation" },
    { re: /\bzapier\b/i, label: "Zapier", category: "AI & Automation" },
    { re: /\bollama\b/i, label: "Ollama", category: "AI & Automation" },
    { re: /\bopenai\b/i, label: "OpenAI API", category: "AI & Automation" },
    { re: /\bllm\b|large language model/i, label: "LLM Integration", category: "AI & Automation" },
    { re: /\bai agent\b/i, label: "AI Agents", category: "AI & Automation" },
    { re: /\bwebhook(s)?\b/i, label: "Webhooks", category: "AI & Automation" },
    { re: /\bgoogle sheets\b/i, label: "Google Sheets API", category: "AI & Automation" },
    { re: /\brest api\b|\bapi\b/i, label: "APIs", category: "Tools & Platforms" },
    { re: /\bgit\b(?!hub)/i, label: "Git", category: "Tools & Platforms" },
    { re: /\bgithub pages\b/i, label: "GitHub Pages", category: "Tools & Platforms" },
    { re: /\bwhatsapp\b/i, label: "WhatsApp Integration", category: "Tools & Platforms" },
    { re: /\bjson\b/i, label: "JSON Processing", category: "Programming" },
  ];

  const PRACTICE_HINTS = /\b(practice|learning|my first|test repo|sandbox|playground|exercises?)\b/i;

  function titleCaseFromRepoName(name) {
    const ACRONYMS = { ai: "AI", api: "API", sql: "SQL", ui: "UI", cv: "CV" };
    return name
      .replace(/[-_]+/g, " ")
      .trim()
      .split(" ")
      .map((w) => {
        const lower = w.toLowerCase();
        if (ACRONYMS[lower]) return ACRONYMS[lower];
        return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
      })
      .join(" ");
  }

  function detectTech(text) {
    const found = new Map();
    if (!text) return found;
    for (const entry of TECH_DICTIONARY) {
      if (entry.re.test(text)) found.set(entry.label, entry.category);
    }
    return found;
  }

  /** Pull the text under a markdown heading whose title matches `nameRe`. */
  function extractSection(readme, nameRe) {
    if (!readme) return null;
    const lines = readme.split("\n");
    let capturing = false;
    let out = [];
    for (const line of lines) {
      const headingMatch = line.match(/^#{1,4}\s+(.*)/);
      if (headingMatch) {
        if (capturing) break; // hit the next heading, stop
        if (nameRe.test(headingMatch[1])) {
          capturing = true;
          continue;
        }
      } else if (capturing) {
        out.push(line);
      }
    }
    const text = out.join("\n").trim();
    return text.length ? text : null;
  }

  function stripMarkdown(text) {
    if (!text) return "";
    return text
      .replace(/```[\s\S]*?```/g, "")
      .replace(/!\[.*?\]\(.*?\)/g, "")
      .replace(/\[(.*?)\]\(.*?\)/g, "$1")
      .replace(/[#*_>`]/g, "")
      .replace(/\r/g, "")
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .join(" ")
      .trim();
  }

  function firstSentences(text, maxLen) {
    const clean = stripMarkdown(text);
    if (clean.length <= maxLen) return clean;
    return clean.slice(0, maxLen).replace(/\s+\S*$/, "") + "…";
  }

  /** Try to pull ordered workflow steps from a README's bullet list, if one exists. */
  function extractWorkflowSteps(readme) {
    const section =
      extractSection(readme, /work\s*flow|how it works|architecture|pipeline/i) ||
      readme;
    if (!section) return null;
    const bulletLines = section
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => /^[-*\d.]/.test(l));
    if (bulletLines.length < 2) return null;
    const steps = bulletLines
      .slice(0, 6)
      .map((l) => stripMarkdown(l.replace(/^[-*\d.)\s]+/, "")))
      .filter((l) => l.length > 0 && l.length < 90);
    return steps.length >= 2 ? steps : null;
  }

  function confidenceLabel(repoCount) {
    if (repoCount >= 4) return "Applied across multiple projects";
    if (repoCount >= 2) return "Practiced in a few projects";
    return "Used in one project";
  }

  /**
   * Build one analyzed project object from a raw repo + its fetched extras.
   */
  function analyzeRepo(repo, { readme, topics, languages }) {
    const isSelfPortfolio = window.PORTFOLIO_CONFIG.SELF_REPO_PATTERN.test(
      repo.name
    );

    const evidenceText = [
      repo.description || "",
      readme || "",
      (topics || []).join(" "),
      repo.language || "",
      Object.keys(languages || {}).join(" "),
    ].join(" \n ");

    const techMap = detectTech(evidenceText);
    const technologies = Array.from(techMap.entries()).map(([label, category]) => ({
      label,
      category,
    }));

    const overview =
      firstSentences(readme, 320) ||
      (repo.description ? repo.description.trim() : "") ||
      "No description or README is available for this repository yet.";

    const problemSection = extractSection(readme, /problem|purpose|why/i);
    const solutionSection = extractSection(
      readme,
      /solution|what it does|how it works|features/i
    );

    const hasReadme = !!(readme && readme.trim().length > 40);
    const hasDescription = !!(repo.description && repo.description.trim().length > 0);
    const looksLikePractice =
      PRACTICE_HINTS.test(evidenceText) ||
      (!hasReadme && !hasDescription && technologies.length === 0);

    let category;
    if (isSelfPortfolio) category = "self";
    else if (looksLikePractice) category = "practice";
    else category = "project";

    const workflowEvidence = /\btrigger\b|\bwebhook\b|\bn8n\b|\bautomation\b|\bworkflow\b/i.test(
      evidenceText
    );
    const workflowSteps = workflowEvidence ? extractWorkflowSteps(readme) : null;

    // A quality/strength score used only for ranking Featured Projects.
    let score = 0;
    if (hasReadme) score += 2;
    if (hasDescription) score += 1;
    score += Math.min(technologies.length, 6) * 0.5;
    if (techMap.has("AI Agents") || techMap.has("Ollama") || techMap.has("n8n") || techMap.has("LLM Integration"))
      score += 3; // relevance to AI/automation focus
    score += Math.min(repo.stargazers_count || 0, 5);
    const daysOld =
      (Date.now() - new Date(repo.pushed_at).getTime()) / (1000 * 60 * 60 * 24);
    score += Math.max(0, 3 - daysOld / 90); // mild recency boost, decays over ~9 months
    if (category !== "project") score -= 10;

    return {
      repoName: repo.name,
      title: titleCaseFromRepoName(repo.name),
      description: overview,
      problem: problemSection ? firstSentences(problemSection, 260) : null,
      solution: solutionSection ? firstSentences(solutionSection, 260) : null,
      technologies,
      category, // "project" | "practice" | "self"
      url: repo.html_url,
      homepage: repo.homepage && repo.homepage.trim() ? repo.homepage.trim() : null,
      stars: repo.stargazers_count || 0,
      forks: repo.forks_count || 0,
      updatedAt: repo.pushed_at,
      createdAt: repo.created_at,
      defaultBranch: repo.default_branch,
      primaryLanguage: repo.language,
      workflowSteps,
      score,
    };
  }

  /** Aggregate a skills map { category: [{label, repoCount, confidence}] } across all analyzed projects. */
  function buildSkills(analyzedRepos) {
    const tally = new Map(); // label -> { category, repos: Set }
    for (const proj of analyzedRepos) {
      for (const tech of proj.technologies) {
        if (!tally.has(tech.label)) {
          tally.set(tech.label, { category: tech.category, repos: new Set() });
        }
        tally.get(tech.label).repos.add(proj.repoName);
      }
    }
    const byCategory = {};
    for (const [label, info] of tally.entries()) {
      byCategory[info.category] = byCategory[info.category] || [];
      byCategory[info.category].push({
        label,
        repoCount: info.repos.size,
        confidence: confidenceLabel(info.repos.size),
      });
    }
    for (const cat in byCategory) {
      byCategory[cat].sort((a, b) => b.repoCount - a.repoCount);
    }
    return byCategory;
  }

  function detectCV(repoContentsByRepo) {
    for (const [repoName, files] of Object.entries(repoContentsByRepo)) {
      const hit = files.find((f) =>
        /^(cv|resume)[-_.]?.*\.(pdf|docx?)$/i.test(f.name)
      );
      if (hit) return { repoName, url: hit.download_url || hit.html_url };
    }
    return null;
  }

  window.GitHubAnalyzer = {
    titleCaseFromRepoName,
    analyzeRepo,
    buildSkills,
    detectCV,
    firstSentences,
    stripMarkdown,
  };
})();
