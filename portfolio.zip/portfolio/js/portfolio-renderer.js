/**
 * js/portfolio-renderer.js
 * Orchestration + DOM rendering. This is the only file that touches the DOM.
 */
(function () {
  const { GITHUB_USERNAME } = window.PORTFOLIO_CONFIG;
  const { getProfile, getRepos, getRepoLanguages, getRepoTopics, getReadme, getRepoContents } =
    window.GitHubAPI;
  const { analyzeRepo, buildSkills, detectCV } = window.GitHubAnalyzer;

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function hide(el) {
    if (el) el.hidden = true;
  }
  function show(el) {
    if (el) el.hidden = false;
  }
  function setText(sel, text) {
    const el = $(sel);
    if (el) el.textContent = text;
  }
  function setHref(sel, href) {
    const el = $(sel);
    if (el && href) {
      el.href = href;
      show(el);
    } else if (el) {
      hide(el);
    }
  }

  function timeAgo(iso) {
    const days = Math.floor((Date.now() - new Date(iso).getTime()) / 86400000);
    if (days < 1) return "today";
    if (days < 2) return "yesterday";
    if (days < 30) return `${days}d ago`;
    if (days < 365) return `${Math.floor(days / 30)}mo ago`;
    return `${Math.floor(days / 365)}y ago`;
  }

  function techBadges(technologies, limit = 6) {
    const list = technologies.slice(0, limit);
    return list
      .map((t) => `<span class="badge">${t.label}</span>`)
      .join("");
  }

  function projectCard(proj, { featured = false } = {}) {
    const demoBtn = proj.homepage
      ? `<a class="btn btn-ghost" href="${proj.homepage}" target="_blank" rel="noopener">Live Demo</a>`
      : "";
    return `
      <article class="card project-card ${featured ? "project-card--featured" : ""}" data-repo="${proj.repoName}">
        <div class="card-top">
          <h3>${proj.title}</h3>
          <span class="meta-dot">·</span>
          <span class="card-updated">Updated ${timeAgo(proj.updatedAt)}</span>
        </div>
        <p class="card-desc">${proj.description}</p>
        <div class="badge-row">${techBadges(proj.technologies)}</div>
        <div class="card-actions">
          <a class="btn btn-primary" href="${proj.url}" target="_blank" rel="noopener">GitHub</a>
          ${demoBtn}
          <button class="btn btn-ghost js-view-details" data-repo="${proj.repoName}">View Details</button>
        </div>
      </article>`;
  }

  function practiceItem(proj) {
    return `<li><a href="${proj.url}" target="_blank" rel="noopener">${proj.title}</a><span class="muted"> — ${proj.primaryLanguage || "misc"}</span></li>`;
  }

  function renderHero(profile) {
    setText("#hero-name", profile.name || profile.login);
    const avatar = $("#hero-avatar");
    if (avatar && profile.avatar_url) {
      avatar.src = profile.avatar_url;
      show(avatar);
    }
    setHref("#btn-github", `https://github.com/${GITHUB_USERNAME}`);
  }

  function renderAbout(profile, analyzedRepos, skills) {
    const realProjects = analyzedRepos.filter((p) => p.category === "project");
    const langs = new Set(
      realProjects.flatMap((p) => p.technologies.map((t) => t.label))
    );
    const focusAreas = [];
    if (skills["AI & Automation"]) focusAreas.push("AI-powered automation workflows");
    if (skills["Web Development"]) focusAreas.push("full-stack web development");
    if (skills["Databases"]) focusAreas.push("working with structured data");

    const bioLine = profile.bio ? profile.bio.trim() + " " : "";
    const parts = [];
    parts.push(
      `${bioLine}${profile.name || profile.login} is an early-career developer focused on ${focusAreas.join(", ") || "software development"}, learning in the open on GitHub.`
    );
    if (realProjects.length) {
      parts.push(
        `Across ${realProjects.length} public project${realProjects.length === 1 ? "" : "s"}, the work spans ${Array.from(langs).slice(0, 6).join(", ") || "several technologies"}.`
      );
    }
    parts.push(
      "Currently open to AI automation internships, automation internships, and junior automation or Python/web development roles."
    );
    setText("#about-text", parts.join(" "));
  }

  function renderFeatured(analyzedRepos) {
    const projects = analyzedRepos
      .filter((p) => p.category === "project")
      .sort((a, b) => b.score - a.score)
      .slice(0, 6);
    const container = $("#featured-projects");
    if (!container) return;
    if (!projects.length) {
      hide($("#featured"));
      return;
    }
    container.innerHTML = projects.map((p) => projectCard(p, { featured: true })).join("");
  }

  function renderAllProjects(analyzedRepos) {
    const projects = analyzedRepos.filter((p) => p.category === "project");
    const container = $("#all-projects");
    if (container) container.innerHTML = projects.map((p) => projectCard(p)).join("");

    const practice = analyzedRepos.filter((p) => p.category === "practice");
    const practiceSection = $("#practice-section");
    const practiceList = $("#practice-list");
    if (practice.length && practiceList) {
      practiceList.innerHTML = practice.map(practiceItem).join("");
      show(practiceSection);
    } else {
      hide(practiceSection);
    }
  }

  function renderSkills(skills) {
    const order = ["AI & Automation", "Programming", "Web Development", "Databases", "Tools & Platforms"];
    const container = $("#skills-grid");
    if (!container) return;
    const groups = order
      .filter((cat) => skills[cat] && skills[cat].length)
      .map((cat) => {
        const items = skills[cat]
          .map(
            (s) =>
              `<li><span class="skill-name">${s.label}</span><span class="skill-meta">${s.repoCount} repo${s.repoCount === 1 ? "" : "s"} · ${s.confidence}</span></li>`
          )
          .join("");
        return `<div class="skill-card"><h3>${cat}</h3><ul>${items}</ul></div>`;
      });
    if (!groups.length) {
      hide($("#skills"));
      return;
    }
    container.innerHTML = groups.join("");
  }

  function renderActivity(profile, repos, analyzedRepos) {
    setHref("#activity-github-link", `https://github.com/${GITHUB_USERNAME}`);
    setText("#stat-repos", String(repos.length));
    const langCount = new Map();
    for (const p of analyzedRepos) {
      if (p.primaryLanguage) langCount.set(p.primaryLanguage, (langCount.get(p.primaryLanguage) || 0) + 1);
    }
    const topLangs = Array.from(langCount.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([l]) => l);
    setText("#stat-languages", topLangs.length ? topLangs.join(", ") : "—");

    const recent = [...repos]
      .sort((a, b) => new Date(b.pushed_at) - new Date(a.pushed_at))
      .slice(0, 5);
    const recentList = $("#recent-activity");
    if (recentList) {
      recentList.innerHTML = recent
        .map(
          (r) =>
            `<li><a href="${r.html_url}" target="_blank" rel="noopener">${r.name}</a><span class="muted"> — updated ${timeAgo(r.pushed_at)}</span></li>`
        )
        .join("");
    }
  }

  function renderCV(cv) {
    setHref("#btn-cv", cv ? cv.url : null);
  }

  function renderContact(profile) {
    setHref("#contact-github", `https://github.com/${GITHUB_USERNAME}`);
    if (profile.email) {
      setHref("#contact-email", `mailto:${profile.email}`);
      setText("#contact-email", profile.email);
    } else {
      hide($("#contact-email-row"));
    }
    if (profile.blog && profile.blog.trim()) {
      const href = /^https?:\/\//.test(profile.blog) ? profile.blog : `https://${profile.blog}`;
      setHref("#contact-website", href);
    } else {
      hide($("#contact-website-row"));
    }
  }

  function wireContactForm(profile) {
    const form = $("#contact-form");
    const status = $("#cf-status");
    if (!form) return;
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = $("#cf-name").value.trim();
      const email = $("#cf-email").value.trim();
      const message = $("#cf-message").value.trim();
      if (!profile.email) {
        status.textContent =
          "No public contact email is set on this GitHub profile — please reach out via the GitHub link instead.";
        return;
      }
      const subject = encodeURIComponent(`Portfolio contact from ${name}`);
      const body = encodeURIComponent(`${message}\n\n— ${name} (${email})`);
      window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
      status.textContent = "Opening your email client…";
    });
  }

  function openModal(proj) {
    const modal = $("#project-modal");
    if (!modal) return;
    $("#modal-title").textContent = proj.title;
    $("#modal-overview").textContent = proj.description;

    const setBlock = (id, label, text) => {
      const el = $(id);
      if (!el) return;
      if (text) {
        el.hidden = false;
        el.innerHTML = `<h4>${label}</h4><p>${text}</p>`;
      } else {
        el.hidden = true;
      }
    };
    setBlock("#modal-problem", "Problem", proj.problem);
    setBlock("#modal-solution", "Solution", proj.solution);

    const workflowEl = $("#modal-workflow");
    if (proj.workflowSteps && proj.workflowSteps.length) {
      workflowEl.hidden = false;
      workflowEl.innerHTML =
        "<h4>Workflow</h4><div class='pipeline'>" +
        proj.workflowSteps
          .map((s) => `<span class="pipeline-node">${s}</span>`)
          .join('<span class="pipeline-arrow">→</span>') +
        "</div>";
    } else {
      workflowEl.hidden = true;
    }

    $("#modal-tech").innerHTML = techBadges(proj.technologies, 20);
    setHref("#modal-github", proj.url);
    setHref("#modal-demo", proj.homepage);

    modal.hidden = false;
    document.body.classList.add("modal-open");
  }

  function wireModal(analyzedRepos) {
    const byName = new Map(analyzedRepos.map((p) => [p.repoName, p]));
    document.addEventListener("click", (e) => {
      const trigger = e.target.closest(".js-view-details");
      if (trigger) {
        const proj = byName.get(trigger.dataset.repo);
        if (proj) openModal(proj);
      }
      if (e.target.matches("#project-modal, .modal-close")) {
        $("#project-modal").hidden = true;
        document.body.classList.remove("modal-open");
      }
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        $("#project-modal").hidden = true;
        document.body.classList.remove("modal-open");
      }
    });
  }

  function showFatalError(message) {
    const el = $("#load-error");
    if (el) {
      el.hidden = false;
      el.textContent = message;
    }
    hide($("#loading-state"));
  }

  async function init() {
    try {
      const [profile, repos] = await Promise.all([getProfile(), getRepos()]);

      const nonForkRepos = repos.filter((r) => !r.fork);

      const extras = await Promise.all(
        nonForkRepos.map(async (repo) => {
          const [readme, topics, languages, contents] = await Promise.all([
            getReadme(repo.name),
            getRepoTopics(repo.name),
            getRepoLanguages(repo.name),
            getRepoContents(repo.name),
          ]);
          return { repo, readme, topics, languages, contents };
        })
      );

      const analyzedRepos = extras.map(({ repo, readme, topics, languages }) =>
        analyzeRepo(repo, { readme, topics, languages })
      );

      const contentsByRepo = Object.fromEntries(
        extras.map(({ repo, contents }) => [repo.name, contents])
      );
      const cv = detectCV(contentsByRepo);

      const skills = buildSkills(analyzedRepos.filter((p) => p.category !== "self"));

      renderHero(profile);
      renderAbout(profile, analyzedRepos, skills);
      renderFeatured(analyzedRepos);
      renderAllProjects(analyzedRepos);
      renderSkills(skills);
      renderActivity(profile, nonForkRepos, analyzedRepos);
      renderCV(cv);
      renderContact(profile);
      wireModal(analyzedRepos);
      wireContactForm(profile);

      document.title = `${profile.name || profile.login} | AI Automation & Workflow Automation Developer`;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute(
          "content",
          `${profile.name || profile.login} — early-career AI automation & workflow automation developer. Real projects and skills pulled live from GitHub (@${GITHUB_USERNAME}).`
        );
      }

      hide($("#loading-state"));
      show($("#site-content"));
    } catch (err) {
      console.error(err);
      if (err && err.rateLimited) {
        showFatalError(
          "GitHub's public API rate limit was hit while loading this page. Please refresh in a few minutes — your data hasn't changed, it just couldn't be fetched right now."
        );
      } else {
        showFatalError(
          "This portfolio couldn't reach the GitHub API just now. Please check your connection and refresh."
        );
      }
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
