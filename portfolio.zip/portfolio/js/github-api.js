/**
 * js/github-api.js
 * Thin, cached wrapper around the public GitHub REST API.
 * Nothing here knows what a "portfolio" is — it only fetches and caches.
 *
 * Caching is in-memory only (a plain object living for the page's
 * lifetime). Browser storage (localStorage/sessionStorage) is
 * intentionally not used here.
 */
(function () {
  const API = "https://api.github.com";
  const { GITHUB_USERNAME, CACHE_TTL_MS } = window.PORTFOLIO_CONFIG;

  const memCache = new Map(); // key -> { value, expires }

  function cacheGet(key) {
    const hit = memCache.get(key);
    if (!hit) return null;
    if (Date.now() > hit.expires) {
      memCache.delete(key);
      return null;
    }
    return hit.value;
  }

  function cacheSet(key, value) {
    memCache.set(key, { value, expires: Date.now() + CACHE_TTL_MS });
  }

  async function fetchJSON(url, cacheKey) {
    if (cacheKey) {
      const cached = cacheGet(cacheKey);
      if (cached !== null) return { data: cached, fromCache: true };
    }
    const res = await fetch(url, {
      headers: { Accept: "application/vnd.github+json" },
    });
    if (!res.ok) {
      const err = new Error(`GitHub API ${res.status} for ${url}`);
      err.status = res.status;
      err.rateLimited =
        (res.status === 403 || res.status === 429) &&
        res.headers.get("x-ratelimit-remaining") === "0";
      throw err;
    }
    const data = await res.json();
    if (cacheKey) cacheSet(cacheKey, data);
    return { data, fromCache: false };
  }

  /** Fetch the user's public profile. */
  async function getProfile() {
    const { data } = await fetchJSON(
      `${API}/users/${GITHUB_USERNAME}`,
      `gh:profile:${GITHUB_USERNAME}`
    );
    return data;
  }

  /** Fetch every public, non-fork repository, paginated. */
  async function getRepos() {
    const cacheKey = `gh:repos:${GITHUB_USERNAME}`;
    const cached = cacheGet(cacheKey);
    if (cached !== null) return cached;

    let page = 1;
    let all = [];
    while (true) {
      const res = await fetch(
        `${API}/users/${GITHUB_USERNAME}/repos?per_page=100&page=${page}&sort=updated`,
        { headers: { Accept: "application/vnd.github+json" } }
      );
      if (!res.ok) {
        const err = new Error(`GitHub API ${res.status} fetching repos`);
        err.status = res.status;
        err.rateLimited =
          (res.status === 403 || res.status === 429) &&
          res.headers.get("x-ratelimit-remaining") === "0";
        throw err;
      }
      const batch = await res.json();
      all = all.concat(batch);
      if (batch.length < 100) break;
      page += 1;
      if (page > 5) break; // sane upper bound
    }
    all = all.filter((r) => !r.private);
    cacheSet(cacheKey, all);
    return all;
  }

  /** Per-repo language byte breakdown (more granular than repo.language). */
  async function getRepoLanguages(repoName) {
    try {
      const { data } = await fetchJSON(
        `${API}/repos/${GITHUB_USERNAME}/${repoName}/languages`,
        `gh:langs:${GITHUB_USERNAME}:${repoName}`
      );
      return data;
    } catch (e) {
      return {};
    }
  }

  /** Repo topics (some accounts/API versions omit these from the repo list call). */
  async function getRepoTopics(repoName) {
    try {
      const { data } = await fetchJSON(
        `${API}/repos/${GITHUB_USERNAME}/${repoName}/topics`,
        `gh:topics:${GITHUB_USERNAME}:${repoName}`
      );
      return data.names || [];
    } catch (e) {
      return [];
    }
  }

  /** README content, decoded from base64. Returns null if none exists. */
  async function getReadme(repoName) {
    try {
      const { data } = await fetchJSON(
        `${API}/repos/${GITHUB_USERNAME}/${repoName}/readme`,
        `gh:readme:${GITHUB_USERNAME}:${repoName}`
      );
      if (!data || !data.content) return null;
      const decoded = decodeURIComponent(
        atob(data.content.replace(/\n/g, ""))
          .split("")
          .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
          .join("")
      );
      return decoded;
    } catch (e) {
      return null; // missing README is expected and fine, not an error
    }
  }

  /** Root-level file listing, used to spot config files (package.json, CV, etc). */
  async function getRepoContents(repoName) {
    try {
      const { data } = await fetchJSON(
        `${API}/repos/${GITHUB_USERNAME}/${repoName}/contents/`,
        `gh:contents:${GITHUB_USERNAME}:${repoName}`
      );
      return Array.isArray(data) ? data : [];
    } catch (e) {
      return [];
    }
  }

  window.GitHubAPI = {
    getProfile,
    getRepos,
    getRepoLanguages,
    getRepoTopics,
    getReadme,
    getRepoContents,
  };
})();
